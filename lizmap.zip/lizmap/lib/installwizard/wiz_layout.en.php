<?php

$locales = array(
'maintitle'=>'installation wizard',
'previousLabel' => 'previous',
'nextLabel'=> 'next',


);
